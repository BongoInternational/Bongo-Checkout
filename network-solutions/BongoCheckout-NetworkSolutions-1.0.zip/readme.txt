﻿Network Solutions Implementation Guide v1.0
Installation:


1. Open bongocheckout.netsol.1.0.js and edit lines 16 and 17, replacing YOUR_CHECKOUT_URL and YOUR_PARTNER_KEY with the applicable information provided by your implementation specialist.
2. Click File Manager in the upper-right corner of the administration area
3. Click the Upload Files button., then click Add
4. Select bongocheckout.netsol.1.0.js and then click Upload
5. From the administration area click Pages
6. Next to Checkout click Edit
7. Under Bottom of Page click View HTML
8. Paste in the following code and save:

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="/bongocheckout.netsol.1.0.js"></script>